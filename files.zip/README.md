# The Pickle Pod – Website

Space-themed pickleball court website for **The Pickle Pod**, located at Villa Rammelyn Garden & Resort, Minglanilla, Philippines.

## How to deploy on GitHub Pages

1. Create a new GitHub repository (e.g. `pickle-pod-website`)
2. Upload all files to the repository root
3. Go to **Settings → Pages**
4. Under "Source", select **Deploy from a branch** → `main` → `/ (root)`
5. Click Save. Your site will be live at `https://yourusername.github.io/pickle-pod-website/`

## File structure

```
/
├── index.html       ← main website (everything is here)
├── logo.png         ← your Pickle Pod logo (rename your logo file to this)
├── img1.jpg         ← podium / awards photo
├── img2.jpg         ← group photo (court 1)
├── img3.jpg         ← group photo (court 2)
├── img4.jpg         ← action shot 1
├── img5.jpg         ← action shot 2
└── README.md
```

## Adding your photos

Rename your image files and upload them alongside `index.html`:

| Rename to | Which photo |
|-----------|-------------|
| `logo.png` | The Pickle Pod logo (Image 1) |
| `img1.jpg` | Podium celebration photo (Image 2) |
| `img2.jpg` | Group photo on court (Image 3) |
| `img3.jpg` | Group photo in front of banner (Image 4) |
| `img4.jpg` | Action shot 1 (Image 5) |
| `img5.jpg` | Action shot 2 (Image 6) |

## Customization tips

- To update pricing, search for `₱500` or `₱300` in `index.html` and change the values
- To update hours, find the `🕒 Hours` section near the bottom
- The booking link points to your ReClub page — no changes needed
